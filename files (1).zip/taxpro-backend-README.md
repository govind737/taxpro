# TaxPro Backend

Full-stack compliance management backend for Indian tax practitioners — GST, ITR, TDS, and other law registrations.

---

## Architecture

```
Internet
   │
   ▼
┌─────────────────────────────────────┐
│   Route 53 (DNS)                    │
│   ACM (TLS/HTTPS certificate)       │
└────────────────┬────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────┐
│   Application Load Balancer (ALB)   │  Public subnets (3 AZs)
│   Port 443 → ECS target group       │
└────────────────┬────────────────────┘
                 │
    ┌────────────┴─────────────┐
    │  ECS Fargate Cluster     │  Private subnets (3 AZs)
    │  ┌──────────────────┐    │
    │  │  Node.js / Express│   │  Auto-scales 1 → 10 tasks
    │  │  port 3000        │   │  CPU: 512  Memory: 1024 MB
    │  └──────────────────┘    │
    └────────────┬─────────────┘
                 │
     ┌───────────┼──────────────┐
     ▼           ▼              ▼
┌─────────┐ ┌─────────┐  ┌──────────────┐
│ Aurora  │ │DynamoDB │  │  S3 Bucket   │
│ PG v16  │ │ 3 tables│  │  (documents) │
│(primary │ │filings  │  │  AES-256     │
│+reader) │ │documents│  │  versioned   │
│Serverles│ │audit-log│  └──────────────┘
│ v2      │ └─────────┘
└─────────┘

Auth:  AWS Cognito User Pool (email+password, JWT RS256)
Logs:  CloudWatch Logs (/taxpro/backend)  90-day retention
Alerts:CloudWatch Alarms → SNS (CPU, memory, RDS)
Secrets: AWS Secrets Manager (DB credentials)
CI/CD: GitHub Actions → ECR → ECS rolling deploy
```

---

## Tech stack

| Layer | Technology |
|---|---|
| Runtime | Node.js 20 LTS |
| Framework | Express 4 |
| ORM (PostgreSQL) | Sequelize 6 |
| NoSQL | AWS DynamoDB (via AWS SDK v3) |
| Auth | AWS Cognito (JWT RS256) |
| Object storage | AWS S3 |
| Email | AWS SES |
| Container | Docker → ECR → ECS Fargate |
| Infrastructure | Terraform ≥ 1.7 |
| CI/CD | GitHub Actions |
| Logging | Winston + CloudWatch |

---

## API reference

### Auth   `/api/v1/auth`
| Method | Path | Description |
|---|---|---|
| POST | `/signup` | Register new CA/accountant |
| POST | `/confirm` | Confirm email OTP |
| POST | `/login` | Get Cognito tokens |
| POST | `/forgot-password` | Send reset code |
| POST | `/reset-password` | Confirm new password |
| GET  | `/me` | Current user profile |
| POST | `/logout` | Global sign-out |

### Clients   `/api/v1/clients`
| Method | Path | Description |
|---|---|---|
| GET | `/` | List clients (paginated, searchable) |
| POST | `/` | Create client |
| GET | `/:id` | Get client with registrations |
| PUT | `/:id` | Update client |
| DELETE | `/:id` | Soft-delete (deactivate) |

### GST   `/api/v1/gst`
| Method | Path | Description |
|---|---|---|
| POST | `/registrations` | New GST registration |
| GET | `/registrations/:clientId` | Get registration |
| PATCH | `/registrations/:id` | Update registration / ARN |
| GET | `/returns` | List returns (filterable) |
| POST | `/returns` | Create return record |
| PATCH | `/returns/:id` | Update summary / mark filed |
| POST | `/returns/:id/invoices` | Bulk upload invoices (DynamoDB) |
| GET | `/returns/:id/invoices` | Fetch invoice detail |

### ITR   `/api/v1/itr`
| Method | Path | Description |
|---|---|---|
| GET | `/` | List ITR filings |
| POST | `/` | Create ITR record |
| GET | `/:id` | Get ITR with client |
| PATCH | `/:id` | Update / mark filed |
| POST | `/:id/computation` | Save computation sheet |
| GET | `/:id/computation` | Get computation sheet |

### TDS   `/api/v1/tds`
| Method | Path | Description |
|---|---|---|
| GET | `/` | List TDS returns |
| POST | `/` | Create return record |
| GET | `/:id` | Get return |
| PATCH | `/:id` | Update / mark filed |
| POST | `/:id/deductees` | Bulk upload deductees |
| GET | `/:id/deductees` | Get deductee list |

### Other Registrations   `/api/v1/registrations`
Supports: `professional_tax`, `epf`, `esi`, `udyam_msme`, `iec`, `shops_establishment`, `fssai`, `trade_license`

| Method | Path | Description |
|---|---|---|
| GET | `/` | List registrations |
| POST | `/` | Create registration |
| GET | `/:id` | Get registration |
| PATCH | `/:id` | Update / change status |
| DELETE | `/:id` | Hard delete |
| GET | `/renewals/upcoming` | Expiring in N days |

### Documents   `/api/v1/documents`
| Method | Path | Description |
|---|---|---|
| POST | `/upload` | Multipart upload → S3 |
| GET | `/presigned-upload` | Get pre-signed PUT URL |
| GET | `/:clientId` | List client documents |
| GET | `/:clientId/download/:s3Key` | Pre-signed GET URL |
| DELETE | `/:clientId/:s3Key` | Delete document |

### Calendar   `/api/v1/calendar`
| Method | Path | Description |
|---|---|---|
| GET | `/?month=6&year=2025` | All compliance events for month |
| GET | `/overdue` | All overdue filings |

### Dashboard   `/api/v1/dashboard`
| Method | Path | Description |
|---|---|---|
| GET | `/summary` | Counts: clients, due, filed, overdue |
| GET | `/recent-activity` | Recent GST/ITR activity |

---

## Local development

```bash
# 1. Clone and install
npm install

# 2. Copy and fill env
cp .env.example .env
# Set COGNITO_USER_POOL_ID and COGNITO_CLIENT_ID (real Cognito values, even in dev)

# 3. Start PostgreSQL + DynamoDB Local + API
docker compose up

# 4. Run migrations + seed
npm run migrate
npm run seed

# 5. Test
npm test
```

---

## AWS deployment

### Prerequisites
- AWS CLI configured (`ap-south-1`)
- Terraform ≥ 1.7 installed
- ACM certificate issued for your domain
- S3 bucket `taxpro-terraform-state` created for remote state
- DynamoDB table `taxpro-tf-lock` for state locking

### 1 — Provision infrastructure
```bash
cd infrastructure/terraform

terraform init
terraform plan \
  -var="acm_certificate_arn=arn:aws:acm:ap-south-1:ACCOUNT:certificate/XXXX" \
  -var="db_master_password=YourStr0ngP@ssword"
terraform apply
```

### 2 — Push first Docker image
```bash
# Get ECR URL from terraform output
ECR_URL=$(terraform output -raw ecr_repository_url)
aws ecr get-login-password --region ap-south-1 | \
  docker login --username AWS --password-stdin $ECR_URL

docker build -t taxpro-api .
docker tag taxpro-api:latest $ECR_URL:latest
docker push $ECR_URL:latest
```

### 3 — Force ECS deployment
```bash
aws ecs update-service \
  --cluster taxpro-production-cluster \
  --service taxpro-production-api \
  --force-new-deployment \
  --region ap-south-1
```

### 4 — CI/CD (ongoing)
Add these GitHub repository secrets:
- `AWS_ACCESS_KEY_ID`
- `AWS_SECRET_ACCESS_KEY`

Every push to `main` → runs tests → builds image → pushes to ECR → rolling deploy to ECS.

---

## Security notes

- All database credentials stored in **AWS Secrets Manager** — never in environment variables in code.
- S3 bucket is fully **private** — all access via pre-signed URLs with 1-hour expiry.
- DynamoDB tables use **server-side encryption**.
- RDS uses **encryption at rest** and **SSL in transit**.
- ECS tasks run as **non-root user** inside the container.
- Cognito enforces **password complexity** and **Advanced Security Mode**.
- Rate limiting: 200 requests / 15 minutes per IP.
- CORS: explicitly configured, credentials-enabled only for allowed origins.

---

## Data storage strategy

| Data type | Store | Reason |
|---|---|---|
| Client master, registrations | RDS PostgreSQL | Relational, queryable, reportable |
| Return summary (totals, status, dates) | RDS PostgreSQL | Dashboards, aggregations, due-date queries |
| Invoice-level detail (GSTR-1 B2B rows) | DynamoDB | Variable schema, high volume, single-client retrieval |
| TDS deductee rows | DynamoDB | Per-return document, bulk ingest |
| ITR computation worksheets | DynamoDB | Per-return JSON blob |
| Scanned documents / PDFs | S3 | Binary objects, lifecycle tiering |
| Audit trail | DynamoDB (TTL 2yr) | Append-only, time-ordered, auto-expiry |
